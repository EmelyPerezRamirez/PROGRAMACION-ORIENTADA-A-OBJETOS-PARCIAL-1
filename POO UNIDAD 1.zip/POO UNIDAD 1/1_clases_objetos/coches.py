"""  
 Programación Orinetada a Objetos POO o OOP

CLASES .- es como un molde a traves del cual se puede instanciar un objeto dentro de las clases se 
definen los atributos (propiedades / caracteristicas) y los métodos (funciones o acciones)
OBJETOS O INSTANCIAS .- son parte de una clase los objetos o instacias pertenecen a una clase, es decir
 para interacturar con la clase o clases y hacer uso de los atributos y metodos es necesario crear un objeto o objetos.

 
"""
#EJEMPLO DE INSTANCIAS
# _PROTEGIDO
# __PRIVADO
# +PUBLICO (puede no ponerse nada)

#Ejemplo 1 Crear una clase (un molde para crear mas objetos)llamada Coches y apartir de la clase crear objetos 
# o instancias (coche) con caracteristicas similares  Atributos: marca, color, modelo, velocidad, potencia numero de 
# asientos y con las operaciones de acelerar y frena que los atributos y metodos sean publicos
#que muestre el color de los carros
#que las operaciones disminuyan o aumenten la velocidad segun sea el caso y hay que jugar con los metodos 
# e imprimes la velocidad al final 

class Coches:
    marca = ""
    color = "no tiene color"
    modelo = ""     
    velocidad = 0
    potencia = 0
    asientos = 0

    def acelerar(self):
        self.velocidad+=1

    def frenar(self):
        self.velocidad-=1



#CREAR OBJETOS 
coche1= Coches ()
coche2= Coches ()

#ASIGANACION forma 1 
print(f"el coche 1 es de color {coche1.color} ")

#no es buena practica ya que se puede modificar los atributos de la clase desde fuera de la clase 

coche1.color="Rojo y blanco"
print(f"el coche 1 es de color {coche1.color} ")

coche2.color="Blanco y negro"
print(f"el coche 2 es de color {coche2.color} ")



for i in range(10,110,10):
    coche1.acelerar()
    coche2.acelerar()

print(f"la velocidad del coche 1 es de {coche1.velocidad} km/h")
print(f"la velocidad del coche 2 es de {coche2.velocidad} km/h")

