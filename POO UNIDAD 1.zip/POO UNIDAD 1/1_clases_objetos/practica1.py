"""
 Practica # 1 Implementar ejercicio el paradigma estructurado VS OO

 Elaborar un programa que calcule el area de un rectangulo
"""
#1
print("\033c")
#Implementar el paradigma estructurado
def area_rectangulo(base, altura):
    return base * altura
print(f"El area del rectangulo es: {area_rectangulo(5, 3)}")

#2
#Implementar el paradigma Orientado a Objetos (OO)
class Rectangulo:
    #constructor = init 
    #init indica que es un constructor, es decir, se ejecuta al momento de crear un objeto
    #los atributos de una clase debe de estar definidos dentro del metodo constructor
    
    def __init__(self, base, altura): #uno por clase
        self.base = base
        self.altura = altura

    def area(self):
        return self.base * self.altura

rect = Rectangulo(5, 3)
print(f"El area del rectangulo es: {rect.area()}") #del objeto rect, se llama al metodo area

#Implementar el paradigma Orientado a Objetos (OO) CASO 2
#no existe clase sin metodo 

class Rectangulos:
    def area (self, base, altura): #metodo normal
        areaR=base*altura
        return areaR

rectangulo1=Rectangulos() #Crear o instanciar un objeto "rectangulo1" de la clase Rectangulos
#cuando no hay un metodo constructor, se puede crear un objeto sin pasarle parametros 
print(f"El area del rectangulo es: {rectangulo1.area(5, 6)}") #del objeto rectangulo1, se llama al metodo area*