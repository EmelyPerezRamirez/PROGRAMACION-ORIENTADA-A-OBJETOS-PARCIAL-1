'''
crear una clase que se llame rectangulo que tenga atributos que sea base y altura que tenga alguno de los dos metodos 

solo puede haber 1 metodo constructor (__init__())
self._altura = altura  #ES UN VALOR PROTEGIDO
self.base = base #ES UN VALOR 

def area_(self): #Valor protegido



EN EL DIAGRAMA:
al momento de poner las variables del metodo se pone el tipo de valor que se pone en ella 
ejemplo: area(area, base):int
 SOLO SI REGRESA VALOR 

EN CASO QUE NO NOS REGRESA VALOR SE PONE VOID
ejemplo: area(area, base):void

'''