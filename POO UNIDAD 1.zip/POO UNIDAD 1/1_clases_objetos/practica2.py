"""
Ejercicio Practico #2 “Modelar y Diagramar en POO”
void
"""
#POR EL METODO CONSTRUCTOR  

print("\033c") 

#Clase de Coches
class Coches: 
    def  __init__(self,color, marca, velocidad ):
      self.__color=color
      self.__marca=marca
      self.__velocidad=velocidad

    def acelerar (self):
       self.__velocidad+=1
       pass

    def frenar (self):
       self.__velocidad-=1

    def tocar_claxon (self):
       print("pi pi pi")


coche1=Coches("blanco","TW", 220)
coche2=Coches("azul","nissan", 180)






